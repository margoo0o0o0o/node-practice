import type { User } from './types';
import { users } from './users';

function getUserById(id: number): User | null {
  return users.find((user) => user.id === id) || null;
}

console.log(getUserById(2));  
console.log(getUserById(99)); 