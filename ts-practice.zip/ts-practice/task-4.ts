import type { User } from './types';
import { users } from './users';

const grouped: Record<string, User[]> = users.reduce((acc, user) => {
  if (!acc[user.city]) {
    acc[user.city] = [];
  }
  acc[user.city]!.push(user); 
  return acc;
}, {} as Record<string, User[]>);

console.log(grouped);