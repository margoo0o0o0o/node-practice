// Описываем тип того, что приходит с сервера (нам нужно только name)
type ApiUser = {
  name: string;
};

// Функция проверки, что данные с сервера — это ApiUser (защита типов)
function isApiUser(value: unknown): value is ApiUser {
  return (
    typeof value === 'object' &&
    value !== null &&
    'name' in value &&
    typeof (value as ApiUser).name === 'string'
  );
}

async function fetchUsers() {
  try {
    const response = await fetch('https://jsonplaceholder.typicode.com/users');
    
    if (!response.ok) {
      throw new Error('Сервер вернул ошибку: ' + response.status);
    }

    const data: unknown = await response.json();

    if (Array.isArray(data)) {
      // Фильтруем массив: оставляем только те элементы, что прошли проверку
      const validUsers = data.filter(isApiUser);
      console.log(validUsers.map((user) => user.name));
    } else {
      console.log('Данные не являются массивом');
    }
  } catch (error) {
    console.error('Ошибка при загрузке данных:', (error as Error).message);
  }
}

fetchUsers();