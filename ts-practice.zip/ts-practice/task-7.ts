import type { User } from './types';
import { users } from './users';

const totalAge: number = users.reduce((acc, user) => acc + user.age, 0);
const averageAge: string = (totalAge / users.length).toFixed(1);
console.log(averageAge);