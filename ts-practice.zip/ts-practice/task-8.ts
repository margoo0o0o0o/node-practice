import type { User } from './types';
import { users } from './users';

const sortedUsers: User[] = [...users].sort((a, b) => {
  const totalA: number = a.orders.reduce((sum, order) => sum + order, 0);
  const totalB: number = b.orders.reduce((sum, order) => sum + order, 0);
  return totalB - totalA;
});

console.log('Отсортированные:', sortedUsers.map((user) => user.name)); 
console.log('Оригинал:', users.map((user) => user.name));