import type { User } from './types';
import { users } from './users';

const best: User = users.reduce((maxUser, currentUser) => {
  const maxTotal: number = maxUser.orders.reduce((sum, order) => sum + order, 0);
  const currentTotal: number = currentUser.orders.reduce((sum, order) => sum + order, 0);
  
  if (currentTotal > maxTotal) {
    return currentUser;
  } 
  return maxUser;
}, users[0]!); 

console.log(best.name);